
------------------------------------------------------
			Rain TPL
	    The easiest PHP template engine
------------------------------------------------------


- Documentation and example at www.raintpl.com
- Feedback and support at info@rainelemental.net
- raintpl files on includes


Thanks,
Federico (www.rainelemental.net).




------------------------------------------------------
	Simplicity is the key to success
------------------------------------------------------